from core.init import start_magomed

if __name__ == "__main__":
    start_magomed(mode="cli")
