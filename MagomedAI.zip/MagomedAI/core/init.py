from core.config_loader import load_config, load_module_config
from core.llm import get_llm
from core.personality import get_personality
from core.state_manager import StateManager
from core.user.model import UserModel
from core.feedback.logger import FeedbackLogger
from core.feedback.tracker import FeedbackTracker
from core.feedback.metrics import FeedbackMetrics
from memory.engine import MemoryEngine

def start_magomed(mode="cli", user_id=None):
    # Загрузка конфигов
    config = load_config()
    module_config = load_module_config(mode)

    # Компоненты
    llm = get_llm(config)
    personality = get_personality(config.get("default_personality", "magomed"), config)
    state = StateManager()
    memory = MemoryEngine()
    user = UserModel()
    logger = FeedbackLogger()
    tracker = FeedbackTracker()
    metrics = FeedbackMetrics()

    # Логируем старт
    logger.info(f"MagomedAI запущен в режиме {mode}")
    if user_id:
        memory.init_user(user_id, mode)
        facts = memory.get_facts(user_id, mode)
        user.update_from_memory(facts)

    # Запуск интерфейса
    if mode == "cli":
        from interfaces.cli import start_cli
        start_cli(llm, memory, personality, state, user, logger, tracker, metrics)
    elif mode == "minecraft":
        from interfaces.minecraft import start_mc
        start_mc(llm, memory, personality, state, user, logger, tracker, metrics)
    elif mode == "discord":
        from interfaces.discord import start_discord
        start_discord(llm, memory, personality, state, user, logger, tracker, metrics)
    else:
        raise ValueError(f"Неизвестный режим запуска: {mode}")
