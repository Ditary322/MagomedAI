from collections import defaultdict
from datetime import datetime

class FeedbackMetrics:
    def __init__(self):
        self.data = defaultdict(int)
        self.session_start = datetime.now()

    def count(self, event_name: str):
        self.data[event_name] += 1

    def report(self):
        return {
            "total_events": sum(self.data.values()),
            "session_duration_minutes": (datetime.now() - self.session_start).seconds // 60,
            "events": dict(self.data)
        }
