from datetime import datetime

class FeedbackTracker:
    def __init__(self):
        self.events = []

    def log_event(self, event_type: str, user_id: str, module: str, details: dict):
        self.events.append({
            "time": datetime.now().isoformat(),
            "type": event_type,
            "user": user_id,
            "module": module,
            "details": details
        })

    def get_events(self):
        return list(self.events)

    def clear(self):
        self.events = []
