import os
from datetime import datetime

class FeedbackLogger:
    def __init__(self, base_path="logs/system"):
        os.makedirs(base_path, exist_ok=True)
        self.path = os.path.join(base_path, "engine.log")

    def log(self, message: str, level: str = "INFO"):
        line = f"[{datetime.now().isoformat()}] [{level.upper()}] {message}\n"
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(line)

    def error(self, message: str):
        self.log(message, level="ERROR")

    def info(self, message: str):
        self.log(message, level="INFO")
