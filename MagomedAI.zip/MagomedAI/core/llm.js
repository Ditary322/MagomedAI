const fetch = require('node-fetch');

const OLLAMA_URL = 'http://localhost:11434/api/generate';
const MODEL_NAME = 'magomed-v1'; // имя твоей fine-tune модели

async function queryGoal(prompt) {
  const response = await fetch(OLLAMA_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: MODEL_NAME,
      prompt: prompt,
      stream: false
    })
  });

  const result = await response.json();

  try {
    // пытаемся найти <<plan>> внутри
    const match = result.response.match(/<<plan>>\s*([\s\S]*)/);
    if (!match) throw new Error('⛔ Нет блока <<plan>> в ответе');

    const planRaw = match[1].trim();

    const plan = JSON.parse(planRaw);
    if (!Array.isArray(plan)) throw new Error('⛔ <<plan>> — не массив');

    return plan;
  } catch (err) {
    console.error('Ошибка при парсинге ответа от LLM:', err.message);
    throw err;
  }
}

module.exports = { queryGoal };