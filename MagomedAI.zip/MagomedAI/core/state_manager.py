from datetime import datetime

class StateManager:
    def __init__(self):
        self._state = {
            "current_goal": None,
            "active_module": None,
            "mood": "neutral",
            "is_busy": False,
            "awaiting_response": False,
            "target_entity": None,
            "last_prompt": None,
            "last_updated": datetime.now().isoformat()
        }

    def get(self, key):
        return self._state.get(key)

    def set(self, key, value):
        self._state[key] = value
        self._state["last_updated"] = datetime.now().isoformat()

    def update(self, **kwargs):
        for k, v in kwargs.items():
            self._state[k] = v
        self._state["last_updated"] = datetime.now().isoformat()

    def all(self):
        return dict(self._state)

    def reset(self):
        self.__init__()
