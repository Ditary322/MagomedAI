# core/db/crud.py

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from . import models
from logger import logger

# --- Операции для Контактов ("Личных дел") ---

async def get_contact_by_nickname(db: AsyncSession, nickname: str) -> models.Contact | None:
    """Найти контакт по одному из его никнеймов."""
    logger.info(f"Поиск контакта в БД по никнейму: {nickname}")
    # Это сложный запрос с объединением (JOIN) таблиц. SQLAlchemy делает его простым.
    result = await db.execute(
        select(models.Contact)
        .join(models.Nickname)
        .filter(models.Nickname.nickname == nickname)
    )
    return result.scalars().first()

async def create_contact(db: AsyncSession, name: str, status: str = "знакомый") -> models.Contact:
    """Создать новый контакт (личное дело)."""
    logger.info(f"Создание нового контакта: Имя='{name}', Статус='{status}'")
    
    # Сначала проверим, не существует ли уже такой контакт
    existing_contact = await get_contact_by_name(db, name=name)
    if existing_contact:
        logger.warning(f"Контакт с именем '{name}' уже существует. Возвращаем существующий.")
        return existing_contact

    # Создаем Python-объект нашей модели
    db_contact = models.Contact(main_name=name, status=status)
    
    # Добавляем его в "сессию" (это как положить в корзину для покупок)
    db.add(db_contact)
    # "Пробиваем на кассе" - сохраняем все, что в корзине, в базу данных
    await db.commit()
    # Обновляем объект, чтобы получить его ID из базы
    await db.refresh(db_contact)
    
    logger.success(f"Контакт '{name}' успешно создан с ID: {db_contact.id}")
    return db_contact


# --- Операции для Никнеймов ---

async def add_nickname_to_contact(db: AsyncSession, contact: models.Contact, nickname: str, platform: str) -> models.Nickname:
    """Добавить новый никнейм существующему контакту."""
    logger.info(f"Добавление никнейма '{nickname}' ({platform}) для контакта '{contact.main_name}'")
    
    # Создаем объект никнейма
    db_nickname = models.Nickname(nickname=nickname, platform=platform, contact_id=contact.id)
    
    db.add(db_nickname)
    await db.commit()
    await db.refresh(db_nickname)
    
    logger.success(f"Никнейм '{nickname}' успешно добавлен.")
    return db_nickname