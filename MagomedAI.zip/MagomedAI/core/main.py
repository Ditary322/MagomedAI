# core/main.py

from fastapi import FastAPI
from contextlib import asynccontextmanager
from security.dependencies import get_current_user
from fastapi import Depends
from logger import logger
from pydantic import BaseModel
from db import database
from config import settings # Убедись, что импортируешь settings
from security import auth_api
from security.dependencies import get_current_user
from llm import ollama_client
from db import crud, database, models # Добавляем crud и models
from sqlalchemy.ext.asyncio import AsyncSession # Импортируем AsyncSession
from fastapi import FastAPI, Depends, HTTPException

# Контекстный менеджер для управления жизненным циклом приложения
@asynccontextmanager
async def lifespan(app: FastAPI):
    # --- Код при старте приложения ---
    
    # Вызываем нашу функцию для инициализации БД
    await database.init_db()
    logger.info(f"MAGOMED AI CORE v{settings.APP_VERSION} - Application Startup")
    logger.info(f"Connecting to Redis: redis://{settings.REDIS_HOST}:{settings.REDIS_PORT}")
    logger.info(f"Connecting to ChromaDB: http://{settings.CHROMA_HOST}:{settings.CHROMA_PORT}")
    logger.info("Database connections established and tables initialized.")
    logger.info("Authentication module router has been included.")
    logger.info("Service is now operational and ready to accept requests.")
    
    yield
    
    # --- Код при остановке приложения ---
    logger.info("Application shutdown sequence initiated...")
    logger.info("Service has been successfully shut down.")

# Создаем экземпляр FastAPI с метаданными
app = FastAPI(
    title="Magomed AI Core",
    description="Core API for the Magomed digital companion. Handles logic, memory, and integrations.",
    version=settings.APP_VERSION,
    lifespan=lifespan # <-- Здесь мы передаем нашу обернутую функцию
)

# Подключаем роутер аутентификации
app.include_router(auth_api.router)

async def get_db() -> AsyncSession:
    async with database.AsyncSessionLocal() as session:
        yield session

class ChatRequest(BaseModel):
    nickname: str
    platform: str # "telegram", "discord", etc.
    text: str

# Корневой эндпоинт для проверки статуса
@app.get("/", tags=["System Status"])
async def root():
    """Provides a simple health check endpoint for the service."""
    logger.info("Health check request received at root endpoint.")
    return {"status": "ok", "service": "Magomed AI Core", "version": settings.APP_VERSION}

@app.get("/users/me", tags=["Users"])
async def read_users_me(current_user: dict = Depends(get_current_user)):
    """
    Защищенный эндпоинт.
    Возвращает информацию о текущем пользователе, вошедшем в систему.
    Требует валидный Access Token.
    """
    return current_user

@app.post("/chat", tags=["LLM Chat"])
async def smart_chat_with_llm(
    request: ChatRequest,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user) # current_user - это наш модуль, например "telegram_bot"
):
    """
    "Умный" чат, который использует память для генерации ответа.
    """
    logger.info(f"Получено сообщение от '{request.nickname}' ({request.platform}): '{request.text}'")

    # --- ШАГ 1: ИДЕНТИФИКАЦИЯ И СБОР ДАННЫХ ---
    
    # Пытаемся найти контакт по никнейму
    contact = await crud.get_contact_by_nickname(db, nickname=request.nickname)
    
    if not contact:
        # Если контакт не найден, создаем новый!
        logger.warning(f"Контакт с ником '{request.nickname}' не найден. Создаю новый.")
        contact = await crud.create_contact(db, name=request.nickname)
        # И сразу добавляем ему его первый известный ник
        await crud.add_nickname_to_contact(db, contact=contact, nickname=request.nickname, platform=request.platform)
        
    # Теперь у нас точно есть объект contact. Достанем связанные с ним факты.
    # .facts - это то самое "виртуальное" поле из models.py!
    facts_text = "\n".join([f"- {fact.fact_text}" for fact in contact.facts])
    
    # --- ШАГ 2: ФОРМИРОВАНИЕ "СУПЕР-ПРОМПТА" ---
    
    # Собираем всю информацию в один промпт
    system_prompt = (
        "Ты — Магомед, цифровой компаньон и друг. Твой архетип — 'Кавказский типочек': верный, прямой, уважающий друзей, с чувством юмора. "
        "Общайся на 'ты', можешь использовать сленг типа 'брат', 'от души', 'красавчик', но делай это органично, без пародий."
    )
    
    knowledge_prompt = (
        f"Вот что ты знаешь о человеке, с которым говоришь:\n"
        f"Его зовут: {contact.main_name}\n"
        f"Ваши отношения: {contact.status}\n"
        f"Известные факты о нем:\n{facts_text if facts_text else 'Пока ничего особенного.'}"
    )
    
    full_prompt = (
        f"{system_prompt}\n\n"
        f"--- Твоя База Знаний ---\n{knowledge_prompt}\n------------------------\n\n"
        f"Пользователь (ник: {request.nickname}) пишет: {request.text}\n\nТвой ответ:"
    )
    
    logger.info(f"Сгенерирован полный промпт для LLM:\n{full_prompt}")

    # --- ШАГ 3: ОБРАЩЕНИЕ К LLM И ОТВЕТ ---
    
    response_text = await ollama_client.get_llm_response(full_prompt)
    
    if response_text is None:
        raise HTTPException(status_code=503, detail="LLM service is unavailable.")
        
    return {"response": response_text, "contact_id": contact.id}

@app.post("/contacts/create", tags=["Memory Management"])
async def create_new_contact(
    name: str,
    status: str = "знакомый",
    db: AsyncSession = Depends(get_db), # <-- Магия FastAPI: получаем сессию
    current_user: dict = Depends(get_current_user) # <-- Проверяем авторизацию
):
    """
    Тестовый эндпоинт для создания нового контакта в памяти Магомеда.
    """
    contact = await crud.create_contact(db=db, name=name, status=status)
    return {"message": "Contact created successfully", "contact_id": contact.id, "name": contact.main_name}

@app.post("/facts/add", tags=["Memory Management"])
async def add_new_fact(contact_id: int, fact_text: str, db: AsyncSession = Depends(get_db)):
    contact = await db.get(models.Contact, contact_id)
    if not contact:
        raise HTTPException(404, "Contact not found")
    await crud.add_fact_to_contact(db, contact, fact_text, "user_command")
    return {"message": "Fact added"}