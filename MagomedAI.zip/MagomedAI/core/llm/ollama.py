import requests
from typing import Optional, List, Dict
from .base import LLM

class OllamaLLM(LLM):
    def __init__(self, model="mistral", endpoint="http://localhost:11434", temperature=0.7, top_p=0.95, max_tokens=512):
        self.model = model
        self.endpoint = endpoint
        self.temperature = temperature
        self.top_p = top_p
        self.max_tokens = max_tokens

    def generate(self, prompt: str, system: Optional[str] = None, history: Optional[List[Dict[str, str]]] = None) -> str:
        messages = []

        if system:
            messages.append({"role": "system", "content": system})
        if history:
            messages.extend(history)
        messages.append({"role": "user", "content": prompt})

        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": self.temperature,
            "top_p": self.top_p,
            "max_tokens": self.max_tokens,
            "stream": False
        }

        response = requests.post(f"{self.endpoint}/api/chat", json=payload)
        response.raise_for_status()
        data = response.json()
        return data.get("message", {}).get("content", "")
