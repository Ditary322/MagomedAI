from abc import ABC, abstractmethod
from typing import Optional, List, Dict

class LLM(ABC):
    @abstractmethod
    def generate(
        self,
        prompt: str,
        system: Optional[str] = None,
        history: Optional[List[Dict[str, str]]] = None
    ) -> str:
        pass
