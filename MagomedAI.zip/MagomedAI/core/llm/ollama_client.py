import httpx
from logger import logger
from config import settings

# Собираем полный адрес нашего Мозга из настроек
OLLAMA_API_URL = f"{settings.OLLAMA_HOST}:{settings.OLLAMA_PORT}/api/generate"

async def get_llm_response(prompt: str) -> str | None:
    """
    Отправляет промпт в Ollama и возвращает текстовый ответ.
    Возвращает None в случае ошибки.
    """
    logger.info(f"Отправка запроса к LLM. Модель: {settings.OLLAMA_DEFAULT_MODEL}")
    
    # Формируем тело запроса для API Ollama
    payload = {
        "model": settings.OLLAMA_DEFAULT_MODEL,
        "prompt": prompt,
        "stream": False # Важно: stream=False означает, что мы ждем полного ответа
    }
    
    # Используем асинхронный HTTP-клиент
    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(OLLAMA_API_URL, json=payload)
            
            # Проверяем, что запрос прошел успешно (код 2xx)
            response.raise_for_status() 
            
            response_data = response.json()
            logger.success("Успешный ответ от LLM получен.")
            return response_data.get("response", "").strip()

    except httpx.RequestError as e:
        logger.error(f"Ошибка при запросе к Ollama: {e}")
        return None
    except Exception as e:
        logger.error(f"Неожиданная ошибка при работе с LLM: {e}")
        return None