from .ollama import OllamaLLM
from core.config_loader import load_config

def get_llm(config=None):
    if config is None:
        config = load_config()

    if config.get("use_local_llm", True):
        return OllamaLLM(
            model=config.get("llm_model", "mistral"),
            endpoint=config.get("ollama_endpoint", "http://localhost:11434"),
            temperature=config.get("temperature", 0.7),
            top_p=config.get("top_p", 0.95),
            max_tokens=config.get("max_tokens", 512)
        )
    else:
        raise NotImplementedError("Пока поддерживается только локальный LLM через Ollama")
