class MagomedError(Exception):
    """Базовая ошибка MagomedAI"""
    pass

class UserNotFound(MagomedError):
    """Пользователь не найден"""
    pass

class InvalidCommand(MagomedError):
    """Команда недействительна"""
    pass

class ModuleNotReady(MagomedError):
    """Модуль не готов к использованию"""
    pass

class MemoryAccessError(MagomedError):
    """Ошибка доступа к памяти"""
    pass
