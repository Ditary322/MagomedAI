import json
import os

CONFIG_PATH = "config/core.json"
MODULE_CONFIG_DIR = "config/modules/"

_cached_config = None
_cached_modules = {}

def load_config(path: str = CONFIG_PATH) -> dict:
    global _cached_config
    if _cached_config is not None:
        return _cached_config

    _cached_config = _load_json_file(path)
    return _cached_config

def load_module_config(name: str) -> dict:
    global _cached_modules
    if name in _cached_modules:
        return _cached_modules[name]

    path = os.path.join(MODULE_CONFIG_DIR, f"{name}.json")
    config = _load_json_file(path)
    _cached_modules[name] = config
    return config

def _load_json_file(path: str) -> dict:
    if not os.path.exists(path):
        raise FileNotFoundError(f"Файл конфигурации не найден: {path}")
    with open(path, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError as e:
            raise ValueError(f"Ошибка в JSON: {e}")
