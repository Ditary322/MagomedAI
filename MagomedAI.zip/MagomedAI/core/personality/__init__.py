from .magomed import MagomedPersonality
from core.config_loader import load_config

def get_personality(name="magomed", config=None):
    config = config or load_config()
    
    styles = {
        "magomed": MagomedPersonality,
        # "chill": ChillPersonality,
    }

    cls = styles.get(name.lower())
    if not cls:
        raise ValueError(f"Неизвестный стиль: {name}")
    
    return cls(config)
