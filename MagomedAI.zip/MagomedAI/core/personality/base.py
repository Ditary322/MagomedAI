from abc import ABC, abstractmethod

class Personality(ABC):
    def __init__(self, config=None):
        self.config = config or {}
    
    @abstractmethod
    def apply(self, prompt: str) -> str:
        """Добавляет стиль к prompt, например — через system-prompt или прямое вмешательство"""
        pass

    def comment_on_action(self, action: str) -> str:
        """Авто-комментарии, когда ИИ делает что-то"""
        return ""

    def joke(self) -> str:
        """Может иногда просто пошутить, если стиль это допускает"""
        return ""
