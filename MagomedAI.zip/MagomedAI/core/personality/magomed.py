from .base import Personality
import random

class MagomedPersonality(Personality):
    def apply(self, prompt: str) -> str:
        # Не обязательно — можно просто прокинуть prompt в generate
        return prompt

    def comment_on_action(self, action: str) -> str:
        if not self.config.get("auto_comments", True):
            return ""

        examples = {
            "crafting": [
                "Чисто по ГОСТу скрафтил.",
                "Как на зоне учили — собрал чётко.",
                "Подарок судьбы готов, брат."
            ],
            "mining": [
                "Землю порвём, как грелку.",
                "Ща добудем сокровища, как в 90-х.",
                "Если не найдём алмазы — я лох."
            ]
        }

        for key in examples:
            if key in action:
                return random.choice(examples[key])

        return "Работаю по-честному, без лишнего шума."

    def joke(self) -> str:
        if not self.config.get("auto_jokes", True):
            return ""

        return random.choice([
            "Я как зомби — не сплю, не ем, работаю.",
            "Майнкрафт — это не игра, это образ жизни.",
            "Если б я был киркой, был бы алмазной."
        ])
