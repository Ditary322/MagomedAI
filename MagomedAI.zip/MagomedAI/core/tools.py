import random
import string
import datetime

def generate_id(prefix="obj", length=6):
    suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=length))
    return f"{prefix}_{suffix}"

def now_iso():
    return datetime.datetime.now().isoformat()

def shorten_text(text, max_len=100):
    return text if len(text) <= max_len else text[:max_len] + "..."

def is_russian(text: str) -> bool:
    return any("а" <= c.lower() <= "я" for c in text)
