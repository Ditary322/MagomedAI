class Mood:
    def __init__(self):
        self.state = "neutral"

    def set(self, mood):
        self.state = mood

    def get(self):
        return self.state

    def is_aggressive(self):
        return self.state == "aggressive"
