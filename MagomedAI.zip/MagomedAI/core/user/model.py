from .preferences import Preferences
from .mood import Mood

class UserModel:
    def __init__(self):
        self.preferences = Preferences()
        self.mood = Mood()

    def update_from_memory(self, facts: list):
        for fact in facts:
            if "любит строить" in fact:
                self.preferences.likes_building = True
            if "боится ночи" in fact:
                self.preferences.fears_night = True
            if "ненавидит копать" in fact:
                self.preferences.avoids_mining = True
