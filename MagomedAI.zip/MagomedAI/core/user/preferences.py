class Preferences:
    def __init__(self):
        self.voice_enabled = False
        self.auto_comments = True
        self.auto_jokes = True

        self.likes_building = False
        self.avoids_pvp = False
        self.fears_night = False
        self.loves_mining = False

    def to_dict(self):
        return self.__dict__
