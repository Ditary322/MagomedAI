import os
import json
from datetime import datetime

class MemoryEngine:
    def __init__(self, base_path="logs/users"):
        self.base_path = base_path

    def _user_path(self, user_id):
        return os.path.join(self.base_path, user_id)

    def _module_path(self, user_id, module):
        return os.path.join(self._user_path(user_id), module)

    def init_user(self, user_id, module):
        user_dir = self._user_path(user_id)
        module_dir = self._module_path(user_id, module)

        os.makedirs(module_dir, exist_ok=True)

        person_path = os.path.join(user_dir, "person.json")
        if not os.path.exists(person_path):
            with open(person_path, "w", encoding="utf-8") as f:
                json.dump({
                    "first_seen": datetime.now().isoformat(),
                    "modules_used": [module],
                    "profile": {
                        "name": None,
                        "age": None,
                        "likes": [],
                        "style": None
                    },
                    "last_active": datetime.now().isoformat()
                }, f, indent=2)
        else:
            # обновим дату и список модулей
            with open(person_path, "r+", encoding="utf-8") as f:
                data = json.load(f)
                data["last_active"] = datetime.now().isoformat()
                if module not in data["modules_used"]:
                    data["modules_used"].append(module)
                f.seek(0)
                json.dump(data, f, indent=2)
                f.truncate()

        # создадим вспомогательные файлы
        for fname, default in {
            "dialog.txt": "",
            "memory.json": [],
            "actions.log": ""
        }.items():
            fpath = os.path.join(module_dir, fname)
            if not os.path.exists(fpath):
                with open(fpath, "w", encoding="utf-8") as f:
                    json.dump(default, f) if isinstance(default, list) else f.write("")

    def save_dialog(self, user_id, module, sender, message):
        path = os.path.join(self._module_path(user_id, module), "dialog.txt")
        line = f"[{datetime.now().isoformat()}] {sender}: {message}\n"
        with open(path, "a", encoding="utf-8") as f:
            f.write(line)

    def save_fact(self, user_id, module, fact):
        path = os.path.join(self._module_path(user_id, module), "memory.json")
        if not os.path.exists(path):
            self.init_user(user_id, module)
        with open(path, "r", encoding="utf-8") as f:
            facts = json.load(f)
        if fact not in facts:
            facts.append(fact)
            with open(path, "w", encoding="utf-8") as f:
                json.dump(facts, f, indent=2)

    def get_facts(self, user_id, module):
        path = os.path.join(self._module_path(user_id, module), "memory.json")
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        return []

    def log_action(self, user_id, module, action):
        path = os.path.join(self._module_path(user_id, module), "actions.log")
        line = f"[{datetime.now().isoformat()}] {action}\n"
        with open(path, "a", encoding="utf-8") as f:
            f.write(line)

    def reset_user_memory(self, user_id, module):
        """Ручной сброс памяти игрока (для админа)."""
        module_path = self._module_path(user_id, module)
        for fname in ["memory.json", "dialog.txt", "actions.log"]:
            fpath = os.path.join(module_path, fname)
            if os.path.exists(fpath):
                os.remove(fpath)
        print(f"[Memory] Память игрока {user_id} в модуле {module} сброшена.")
